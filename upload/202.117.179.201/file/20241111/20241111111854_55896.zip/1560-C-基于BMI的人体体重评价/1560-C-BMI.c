#include <stdio.h>

char evaBMI(double, double);

int main()
{
    double w, h;

    scanf("%lf%lf", &w, &h);

    printf("%c\n", evaBMI(w,h));

    return 0;
}

char evaBMI(double w, double h)
{
    double b;

    // 非法参数(避免浮点数的判等)
    if(!(w > 0) || !(h > 0))
    {
        return 'E';
    }

    // BMI指数计算
    b = w / (h * h);

    // 分析结果(避免浮点数的判等)
    if(b < 18.5)
    {
        return 'S';
    }
    else if(b < 24.0)
    {
        return 'N';
    }
    else if(b < 28.0)
    {
        return 'O';
    }
    else
    {
        return 'F';
    }
}
