#include <stdio.h>
#include <stdlib.h>

#define N 30

void total(int s[], int n, int m);
void output(int s[], int n);
void sort(int s[],int n);

int main()
{
    int score[N] = {0};
    int nq, num; // 小题数量和人数

    scanf("%d%d", &num, &nq);

    total(score, num, nq);
    sort(score, num);

    output(score, num);

    return 0;
}

void output(int s[], int n)
{
    int i;

    for (i = 0; i < n - 1; i++)
    {
        printf("%d ", s[i]);
    }

    printf("%d\n",s[i]);
}

void total(int s[], int n, int m)
{
    int i, j;
    int grade;
    int sum;

    // n个学生
    for(i = 0; i < n; i++)
    {
        // m个小题求和
        sum = 0;
        for(j = 0; j < m; j++)
        {
            scanf("%d", &grade);
            sum += grade;
        }

        // 为数组赋值
        s[i] = sum;
    }
}

// qsort的比较函数
int cmp(const void *p, const void *q)
{
    int np = *(const int*)p;
    int nq = *(const int*)q;
    return (np > nq) - (np < nq);
}

void sort(int s[],int n)
{
    qsort(s, n, sizeof(s[0]), cmp);
}
