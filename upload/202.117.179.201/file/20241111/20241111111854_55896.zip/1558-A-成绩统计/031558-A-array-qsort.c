#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define N 200

int input(double *, int);
double get_average(double *, int);
double get_sum(double *, int);

int cmp(const void*, const void*);

int main(void)
{
    int cnt;
    double score[N] = { -1.0 };
    double avg;

    // 读入数据并返回读入总数
    cnt = input(score, N);
    // 计算平均值
    avg = get_average(score, cnt);

    printf("%0.2f\n", avg);

    return 0;
}


// 读入数据
int input(double *pa, int n)
{
    int i;
    double score;

    // 初始化
    i = 0;
    // 读入-1.0结束
    while(1)
    {
        // 读入一个成绩
        scanf("%lf", &score);

        // 是否为-1.0
        if((fabs(score + 1.0) < 1E-10))
        {
            break;
        }

        // 赋值
        pa[i] = score;

        // 计数
        i++;
    }

    // 读取的成绩个数
    return i;
}

double get_sum(double *pa, int n)
{
    int i;
    double sum = 0.0;

    for(i = 0; i < n; i++)
    {
        sum += pa[i];
    }

    return sum;
}

// qsort的比较函数
int cmp(const void* pa, const void* pb)
{
    double a = *(const double *)pa;
    double b = *(const double *)pb;

    return (a > b) - (a < b);
}

// 计算平均成绩
double get_average(double *pa, int n)
{
    int i;
    double sum = 0.0, avg;

    // 排序(部分排序)
    qsort(pa, n, sizeof(pa[0]), cmp);

    // 求和，去掉最小值和最大值
    sum = get_sum(pa + 1, n - 2);

    // 计算平均值
    avg = sum / (n - 2);

    return avg;
}

