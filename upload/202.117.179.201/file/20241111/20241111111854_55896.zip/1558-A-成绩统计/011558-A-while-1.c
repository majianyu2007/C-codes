#include <stdio.h>
#include <math.h>

int main(void)
{
    int cnt;
    double score, sum;
    double max = 0.0, min = 100.0;
    double avg;

    // 初始化
    cnt = 0;
    sum = 0.0;
    while(1)
    {
        scanf("%lf", &score);

        if(fabs(score + 1) < 1E-10) // 结束条件
        {
            break;
        }

        if(max < score)
        {
            max = score; // 更新最大值
        }
        if(min > score)
        {
            min = score; // 更新最小值
        }

        // 求和
        sum += score;
        // 计数
        cnt++;
    }

    // 去掉最大值和最小值
    sum -= max + min;
    // 计数减2
    cnt -= 2;
    // 求平均值
    avg = sum / cnt;

    printf("%0.2f\n", avg);

    return 0;
}
