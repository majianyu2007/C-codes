#include <stdio.h>
#include <string.h>

#define LEN 256

int isValidPasswd (const char *pw, int n);

int main()
{
    char pass[LEN]= {0};
    int len;

    fgets(pass, LEN, stdin);
    len=strlen(pass);
    if(pass[len-1]=='\n')
    {
        pass[len-1] = '\0';
        len--;
    }
    printf("%s RESULT = %d\n", pass, isValidPasswd(pass, len));
    return 0;
}

int isValidPasswd (const char *pw, int n)
{
    int i;
    int flag1 = 0, flag2 = 0, flag3 = 0, flag4 = 0;
    char *s = pw;

    for(; s < pw + n; s++)
    {
        if(*s >= 'a' && *s <= 'z')
        {
            flag1 = 1;
        }
        else if(*s >= 'A' && *s <= 'Z')
        {
            flag2 = 2;
        }
        else if(*s >= '0' && *s <= '9')
        {
            flag3 = 4;
        }
        else
        {
            flag4 = 8;
        }
    }

    return 15 - (flag1 + flag2 + flag3 + flag4);
}
