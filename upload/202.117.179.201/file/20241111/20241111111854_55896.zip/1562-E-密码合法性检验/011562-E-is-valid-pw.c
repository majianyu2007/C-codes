#include <stdio.h>
#include <string.h>

#define LEN 256

int isValidPasswd (const char *pw, int n);

int main()
{
    char pass[LEN]= {0};
    int len;

    fgets(pass, LEN, stdin);
    len=strlen(pass);
    if(pass[len-1]=='\n')
    {
        pass[len-1] = '\0';
        len--;
    }
    printf("%s RESULT = %d\n", pass, isValidPasswd(pass, len));
    return 0;
}

int isValidPasswd (const char *pw, int n)
{
    int i;
    int flag1 = 0, flag2 = 0, flag3 = 0, flag4 = 0;

    for(i = 0; i < n; i++)
    {
        if(pw[i] >= 'a' && pw[i] <= 'z')
        {
            flag1 = 1;
        }
        else if(pw[i] >= 'A' && pw[i] <= 'Z')
        {
            flag2 = 2;
        }
        else if(pw[i] >= '0' && pw[i] <= '9')
        {
            flag3 = 4;
        }
        else
        {
            flag4 = 8;
        }
    }

    return 15 - (flag1 + flag2 + flag3 + flag4);
}
